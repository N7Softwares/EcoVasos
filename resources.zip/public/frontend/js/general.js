document.querySelector('#menu-toggle').addEventListener('click', function () {
  document.querySelector('#site-nav').classList.toggle('active')
  document.querySelector('body').classList.toggle('no-scroll')
  });
