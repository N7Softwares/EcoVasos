<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminWordpressRedirectController extends Controller
{
    public function index()
    {
        return view('frontend.pages.admin-NcIlCOPErc');
    }

}
