<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ImagesCategory extends Model
{
    protected $fillable = ['image_type'];
}
